# Project Name

[![Visual Review](https://img.shields.io/endpoint?url=https://<user>.github.io/<repo>/status.json)](https://github.com/<user>/<repo>/actions/workflows/visual-review.yml)

Your project description here...

---

## 🔍 Visual Review Status

This badge shows the latest **visual review result** from GitHub Actions:

- ✅ **Approved** – No visual regressions detected  
- ⚠️ **Warning** – Coverage below threshold or partial issues  
- ❌ **Failed** – Visual review failed or regressions detected  

🔗 [Workflow Runs](https://github.com/<user>/<repo>/actions/workflows/visual-review.yml)  
